/*jslint devel: true, node: true*/

var firstname = prompt('What is your first name?');

var lastname = prompt('What is your last name?');

var favoriteColor = prompt('What is your favorite color?');

alert(firstname + ' ' + lastname + ' ' + favoriteColor);